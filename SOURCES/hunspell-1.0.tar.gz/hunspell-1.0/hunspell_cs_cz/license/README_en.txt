﻿The pack contains current versions of all OpenOffice.org Czech dictionares as of 2008-05-18.

Spellchecker
------------

This dictionary for spell-checking Czech texts is licensed under GPL license.

The dictionary is based on Czech ispell dictionary created by Petr Kolar
and numerous contributors.

Thesaurus
----------

Copyright (c) 1994,2008 Karel Pala, Jan Všianský
pala@fi.muni.cz

You can freely use the thesaurus in OpenOffice.org (or its derivatives).
You can not modify it or use for commercial purposes without the author's
approval.

Hyphenation dictionary
----------------------

Language: Czech (Czech Republic) (cs CZ).
Origin:   Based on the TeX hyphenation tables
License:  GPL license, 2003
Author:   Pavel@Janik.cz (Pavel Janík)

HYPH cs CZ hyph_cs

 These patterns were converted from TeX hyphenation patterns by the package
 lingucomponent-tools
 (http://cvs.sourceforge.net/cgi-bin/viewcvs.cgi/oo-cs/lingucomponent-tools/).

 The license of original files is GNU GPL (they are both parts of csTeX). My
 work on them was to only run the scripts from lingucomponent-tools package
 (dual LGPL/SISSL license so it can be integrated).
 --
 Pavel Janík
 2003


