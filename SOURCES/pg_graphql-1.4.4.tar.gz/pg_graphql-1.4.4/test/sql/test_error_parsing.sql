select graphql.resolve(
    'query MyQuery { { extra brack }'
)
