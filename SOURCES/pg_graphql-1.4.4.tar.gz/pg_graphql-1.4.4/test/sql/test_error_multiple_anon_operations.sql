select graphql.resolve(
    query:='{ anon1 } { anon2 }'
)
