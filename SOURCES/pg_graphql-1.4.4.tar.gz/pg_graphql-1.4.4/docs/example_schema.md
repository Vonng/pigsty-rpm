The following is a complete example showing how a sample SQL schema translates into a GraphQL schema.

```sql
--8<-- "docs/assets/demo_schema.sql"
```

```graphql
--8<-- "docs/assets/demo_schema.graphql"
```
