\echo Use "ALTER EXTENSION svector UPDATE TO '0.5.1'" to load this file. \quit
