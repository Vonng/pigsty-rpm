\echo Use "ALTER EXTENSION svector UPDATE TO '0.4.3'" to load this file. \quit
