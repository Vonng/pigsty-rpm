\echo Use "ALTER EXTENSION svector UPDATE TO '0.3.13'" to load this file. \quit
