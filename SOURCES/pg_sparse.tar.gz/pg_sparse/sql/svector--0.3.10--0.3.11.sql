\echo Use "ALTER EXTENSION svector UPDATE TO '0.3.11'" to load this file. \quit
