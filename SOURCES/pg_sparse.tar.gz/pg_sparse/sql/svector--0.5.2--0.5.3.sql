\echo Use "ALTER EXTENSION svector UPDATE TO '0.5.3'" to load this file. \quit
