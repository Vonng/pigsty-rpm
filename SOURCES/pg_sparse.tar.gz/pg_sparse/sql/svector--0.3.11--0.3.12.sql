\echo Use "ALTER EXTENSION svector UPDATE TO '0.3.12'" to load this file. \quit
