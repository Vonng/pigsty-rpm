\echo Use "ALTER EXTENSION svector UPDATE TO '0.4.4'" to load this file. \quit
