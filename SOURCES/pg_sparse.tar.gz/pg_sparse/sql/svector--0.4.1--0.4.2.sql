\echo Use "ALTER EXTENSION svector UPDATE TO '0.4.2'" to load this file. \quit
