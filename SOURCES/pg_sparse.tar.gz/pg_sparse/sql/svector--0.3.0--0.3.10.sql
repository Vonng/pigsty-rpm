\echo Use "ALTER EXTENSION svector UPDATE TO '0.3.10'" to load this file. \quit
