begin;
    create table account(
        id serial primary key,
        first_name varchar(255) not null,
        last_name varchar(255) not null
    );

    -- Extend with function
    create function _full_name(rec public.account)
        returns text
        immutable
        strict
        language sql
    as $$
        select format('%s %s', rec.first_name, rec.last_name)
    $$;

    comment on function public._full_name(public.account) is E'@graphql({"name": "wholeName"})';

    -- expect: 'wholeName'
    select jsonb_pretty(
        graphql.resolve($$
        {
          __type(name: "Account") {
            fields {
              name
            }
          }
        }
        $$)
    );

rollback;
