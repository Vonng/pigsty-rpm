select graphql.resolve(
    query:='query QueryA { named }
            { anon }'
)
