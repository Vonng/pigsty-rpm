select graphql.resolve($$
{ { {
    shouldFail
  }
}
$$);
