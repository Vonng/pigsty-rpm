select graphql.resolve(
    query:='subscription Abc { anon }'
)
