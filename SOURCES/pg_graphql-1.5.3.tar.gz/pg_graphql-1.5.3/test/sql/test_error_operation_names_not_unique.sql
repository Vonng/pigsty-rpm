select graphql.resolve(
    query:='query ABC { anon }
            query ABC { other }'
)
