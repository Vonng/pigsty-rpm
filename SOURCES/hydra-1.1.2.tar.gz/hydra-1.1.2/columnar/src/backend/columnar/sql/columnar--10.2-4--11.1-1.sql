-- columnar--10.2.4--11.1-1.sql

-- empty placeholder to allow standalone installation