-- columnar--11.1-6--11.1-7.sql

#include "udfs/alter_table_set_access_method/11.1-8.sql"