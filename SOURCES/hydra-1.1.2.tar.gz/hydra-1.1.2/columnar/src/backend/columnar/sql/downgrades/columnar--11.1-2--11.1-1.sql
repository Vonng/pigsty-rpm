-- columnar--11.1-2--11.1-1.sql

DROP FUNCTION columnar.alter_table_set_access_method();