-- columnar--11.1-1--11.2-1.sql

#include "udfs/alter_table_set_access_method/11.1-2.sql"
