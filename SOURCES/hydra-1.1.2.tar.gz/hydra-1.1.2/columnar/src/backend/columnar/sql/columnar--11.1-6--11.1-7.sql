-- columnar--11.1-6--11.1-7.sql

#include "udfs/vacuum/11.1-7.sql"
