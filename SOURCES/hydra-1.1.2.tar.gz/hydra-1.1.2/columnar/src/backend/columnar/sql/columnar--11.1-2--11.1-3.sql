-- columnar--11.1-1--11.2-1.sql

#include "udfs/alter_columnar_table_set/11.1-3.sql"
#include "udfs/alter_columnar_table_reset/11.1-3.sql"
