-- columnar--10.0-2--10.0-3.sql

-- placeholder, no changes 