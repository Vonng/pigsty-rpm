create database test;
use test;

CREATE TABLE warehouse (
    warehouse_id int primary key,
    warehouse_name varchar(255),
    warehouse_created timestamp
);
