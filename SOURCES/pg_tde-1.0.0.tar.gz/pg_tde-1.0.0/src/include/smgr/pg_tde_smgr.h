
#pragma once

extern void RegisterStorageMgr();
