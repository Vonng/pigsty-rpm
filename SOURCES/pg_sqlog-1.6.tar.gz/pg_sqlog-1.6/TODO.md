- fix preparable_query
  (duration: ?.527 ms  bind S_2: WITH balance_max_date AS (SELECT)
