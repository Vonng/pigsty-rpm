-- columnar--11.1-4--11.1-4.sql

DROP FUNCTION columnar.create_table_row_mask();

DROP TABLE columnar.row_mask;

DROP SEQUENCE columnar.row_mask_seq;