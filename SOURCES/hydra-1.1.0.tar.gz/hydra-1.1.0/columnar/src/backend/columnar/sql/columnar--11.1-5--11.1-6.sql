-- columnar--11.1-5--11.1-6.sql

#include "udfs/vacuum/11.1-6.sql"
