-- columnar--11.1-3--11.1-2.sql

#include "udfs/alter_columnar_table_set/11.1-2.sql"
#include "udfs/alter_columnar_table_reset/11.1-2.sql"
