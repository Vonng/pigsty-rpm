-- columnar--9.5-1.sql

-- empty placeholder to allow standalone installation