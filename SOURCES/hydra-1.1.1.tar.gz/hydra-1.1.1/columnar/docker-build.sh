#!/bin/sh

REPO=hydra/columnar
TAG=latest

docker build -t $REPO:$TAG .