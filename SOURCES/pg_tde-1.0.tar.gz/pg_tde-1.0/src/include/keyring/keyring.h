
#pragma once

void keyringInitialize(void);
