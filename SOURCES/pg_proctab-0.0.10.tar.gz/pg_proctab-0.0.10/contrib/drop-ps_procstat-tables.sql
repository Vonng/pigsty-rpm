DROP TABLE ps_indexstat;
DROP TABLE ps_tablestat;
DROP TABLE ps_dbstat;
DROP TABLE ps_memstat;
DROP TABLE ps_cpustat;
DROP TABLE ps_procstat;
DROP TABLE ps_snaps;
