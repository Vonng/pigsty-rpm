select
    graphql.comment_directive(
        comment_ := '@graphql({"name": "myField"})'
    )
