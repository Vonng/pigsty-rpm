## enforce_password_expiration

Enforces password expiration rules. Uses the `passcheck` hook.

### Installation
---
To install the extension, configure the Postgres database target in `../env.ini`, then run `make install`.
