## client_lockout

Locks out database users after 5 consecutive failed logins. Uses the `clientauth` hook.

### Installation
---
To install the extension, configure the Postgres database target in `../env.ini`, then run `make install`.
