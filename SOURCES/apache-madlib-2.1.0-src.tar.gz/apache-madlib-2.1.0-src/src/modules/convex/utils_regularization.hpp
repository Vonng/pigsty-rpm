
DECLARE_UDF(convex, utils_var_scales_transition)
DECLARE_UDF(convex, utils_var_scales_merge)
DECLARE_UDF(convex, utils_var_scales_final)
DECLARE_UDF(convex, __utils_var_scales_result)
DECLARE_UDF(convex, utils_normalize_data)
DECLARE_UDF(convex, utils_var_scales_non_zero_std_final)
