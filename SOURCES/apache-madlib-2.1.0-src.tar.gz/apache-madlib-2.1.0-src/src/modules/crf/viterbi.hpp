/* ----------------------------------------------------------------------- *//**
 *
 * @file viterbi.hpp
 *
 *//* ----------------------------------------------------------------------- */
/**
 * @brief Viterbi inferencing for best label sequence.
 */
DECLARE_UDF(crf, vcrf_top1_label)
