
DECLARE_UDF(stats, coxph_a_b_transition)
DECLARE_UDF(stats, coxph_a_b_merge)
DECLARE_UDF(stats, coxph_a_b_final)

DECLARE_UDF(stats, coxph_compute_w)
DECLARE_UDF(stats, coxph_compute_clustered_stats)
