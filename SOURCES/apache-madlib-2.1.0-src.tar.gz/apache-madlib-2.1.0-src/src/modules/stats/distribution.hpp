/* ----------------------------------------------------------------------- *//**
 *
 * @file distribution.hpp
 *
 *//* ----------------------------------------------------------------------- */

DECLARE_UDF(stats, vectorized_distribution_transition)
DECLARE_UDF(stats, vectorized_distribution_final)

DECLARE_UDF(stats, discrete_distribution_transition)
DECLARE_UDF(stats, discrete_distribution_final)
