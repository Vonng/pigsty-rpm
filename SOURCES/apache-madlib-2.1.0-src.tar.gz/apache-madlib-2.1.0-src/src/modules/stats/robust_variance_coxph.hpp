
DECLARE_UDF(stats, rb_coxph_step_transition)
DECLARE_UDF(stats, rb_coxph_step_final)
DECLARE_UDF(stats, coxph_h_s_transition)
DECLARE_UDF(stats, coxph_h_s_merge)
DECLARE_UDF(stats, coxph_h_s_final)
DECLARE_UDF(stats, rb_coxph_strata_step_final)
DECLARE_UDF(stats, rb_sum_strata_transition)
DECLARE_UDF(stats, rb_sum_strata_final)
