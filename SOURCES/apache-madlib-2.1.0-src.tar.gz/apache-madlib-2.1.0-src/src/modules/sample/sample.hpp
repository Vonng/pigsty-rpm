/* -----------------------------------------------------------------------------
 *
 * @file sample.hpp
 *
 * @brief Umbrella header that includes all sampling headers
 *
 * -------------------------------------------------------------------------- */

#include "weighted_sample.hpp"
#include "random_process.hpp"
