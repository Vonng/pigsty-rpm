/* ----------------------------------------------------------------------- *//**
 *
 * @file random_forest.hpp
 *
 *//* ----------------------------------------------------------------------- */


DECLARE_UDF(recursive_partitioning, rf_cat_imp_score)
DECLARE_UDF(recursive_partitioning, rf_con_imp_score)
DECLARE_UDF(recursive_partitioning, normalize_sum_array)
