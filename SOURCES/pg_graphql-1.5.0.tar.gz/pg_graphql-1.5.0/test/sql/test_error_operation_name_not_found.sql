select graphql.resolve(
    query:='query ABC { anon }',
    "operationName":='DEF'
)
