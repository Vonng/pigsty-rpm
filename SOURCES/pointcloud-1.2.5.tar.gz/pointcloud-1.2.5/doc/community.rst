.. _community:

******************************************************************************
Community
******************************************************************************

pgPointcloud's community interacts through `Mailing List`_ and `GitHub`_.
The `Mailing List`_ communication channel is for general questions and
feedback. The `GitHub`_ communication channel is for development activities,
bug reports, and testing.

.. _`Mailing List`: http://lists.osgeo.org/mailman/listinfo/pgpointcloud
.. _`GitHub`: https://github.com/pgpointcloud/pointcloud
